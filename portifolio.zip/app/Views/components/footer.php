<footer class="text-center py-2 border-t-2 border-gray-400">
  Desenvolvido por Bruno Teixeira
</footer>
<script src="<?= base_url('/js/main.js') ?>"></script>
</body>

</html>